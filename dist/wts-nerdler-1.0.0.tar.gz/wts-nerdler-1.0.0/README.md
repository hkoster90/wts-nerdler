# wts-nerdler
Windows Task Scheduler Framework by Nerdler.Tech
Requires access to Powershell